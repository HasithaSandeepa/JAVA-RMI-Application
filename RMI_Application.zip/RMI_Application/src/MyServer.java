import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class MyServer {
    public static void main(String[] args) {
        try {
            Hello skel = new HelloRemote();
            Registry rgstry = LocateRegistry.createRegistry(1888);
            rgstry.rebind("myfirst",skel);
            System.out.println("Server bound successfully.");
        } catch (Exception e) {
            System.out.println("Can't connect to the Server.");
            System.out.println("Error: " + e);
            e.printStackTrace();
        }
    }
}
