import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class HelloRemote extends UnicastRemoteObject implements Hello {
    protected HelloRemote() throws RemoteException {
        super();
    }

    @Override
    public String printHello() {
        return "Hello World.!";
    }

    public static void main(String[] args) {
        try {
            // Create an instance of the HelloRemote object
            HelloRemote obj = new HelloRemote();

            // Bind this object instance to the name "Hello server"
            Naming.rebind("Hello server", obj);

            System.out.println("Hello server is running...");
        } catch (Exception e) {
            System.out.println("Hello error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
